from django.shortcuts import render
from core.views import home
# Create your views here.
